export interface Certificate {
  rowIndex: number;
  name: string;
  email: string;
  domain: string;
  certificateId: string;
  issueDate: string;
  status: CertificateStatus;
  sentDate?: string;
}

export type CertificateStatus = 'Pending' | 'Generated' | 'Sent' | 'Failed';

export interface DashboardStats {
  total: number;
  pending: number;
  generated: number;
  sent: number;
  failed: number;
}

export interface BulkResult {
  total: number;
  success: number;
  failed: number;
  errors: { certificateId: string; error: string }[];
}

export interface AuditLog {
  id: string;
  action: string;
  certificateId?: string;
  details: string;
  timestamp: string;
  success: boolean;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}
