import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: number | string;
  icon: LucideIcon;
  color: 'blue' | 'amber' | 'emerald' | 'purple' | 'red';
  sub?: string;
}

const COLOR_MAP = {
  blue: {
    icon: 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400',
    value: 'text-blue-700 dark:text-blue-300',
  },
  amber: {
    icon: 'bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400',
    value: 'text-amber-700 dark:text-amber-300',
  },
  emerald: {
    icon: 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400',
    value: 'text-emerald-700 dark:text-emerald-300',
  },
  purple: {
    icon: 'bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400',
    value: 'text-brand-700 dark:text-brand-300',
  },
  red: {
    icon: 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400',
    value: 'text-red-700 dark:text-red-300',
  },
};

export function StatCard({ label, value, icon: Icon, color, sub }: StatCardProps) {
  const colors = COLOR_MAP[color];
  return (
    <div className="card flex items-start gap-4 hover:shadow-card-hover transition-shadow">
      <div className={cn('p-2.5 rounded-xl flex-shrink-0', colors.icon)}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-sm text-[var(--text-muted)] font-medium">{label}</p>
        <p className={cn('text-3xl font-bold mt-0.5 leading-none', colors.value)}>{value}</p>
        {sub && <p className="text-xs text-[var(--text-muted)] mt-1">{sub}</p>}
      </div>
    </div>
  );
}
