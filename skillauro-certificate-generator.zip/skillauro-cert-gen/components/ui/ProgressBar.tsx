'use client';

interface ProgressBarProps {
  total: number;
  success: number;
  failed: number;
  label?: string;
}

export function ProgressBar({ total, success, failed, label }: ProgressBarProps) {
  const processed = success + failed;
  const pct = total > 0 ? Math.round((processed / total) * 100) : 0;

  return (
    <div className="space-y-2">
      {label && <p className="text-sm font-medium text-[var(--text)]">{label}</p>}
      <div className="flex items-center gap-3">
        <div className="flex-1 h-2.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <div
            className="h-full bg-brand-600 rounded-full transition-all duration-300"
            style={{ width: `${pct}%` }}
          />
        </div>
        <span className="text-sm font-medium text-[var(--text-muted)] w-12 text-right">
          {pct}%
        </span>
      </div>
      <div className="flex gap-4 text-xs text-[var(--text-muted)]">
        <span>Total: <strong className="text-[var(--text)]">{total}</strong></span>
        <span className="text-emerald-600">✓ {success}</span>
        {failed > 0 && <span className="text-red-500">✕ {failed}</span>}
      </div>
    </div>
  );
}
