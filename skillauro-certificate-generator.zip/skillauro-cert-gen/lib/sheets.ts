import { google } from 'googleapis';
import { Certificate, CertificateStatus } from '@/types';

function getAuth() {
  const privateKey = (process.env.GOOGLE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  return new google.auth.GoogleAuth({
    credentials: {
      client_email: process.env.GOOGLE_CLIENT_EMAIL,
      private_key: privateKey,
    },
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });
}

function getSheets() {
  return google.sheets({ version: 'v4', auth: getAuth() });
}

const SHEET_ID = process.env.GOOGLE_SHEET_ID!;
const RANGE = 'Sheet1!A2:G';

export async function getAllCertificates(): Promise<Certificate[]> {
  const sheets = getSheets();
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId: SHEET_ID,
    range: RANGE,
  });

  const rows = response.data.values || [];
  return rows
    .map((row, index) => ({
      rowIndex: index + 2, // 1-indexed, row 1 is header
      name: row[0] || '',
      email: row[1] || '',
      domain: row[2] || '',
      certificateId: row[3] || '',
      issueDate: row[4] || '',
      status: (row[5] || 'Pending') as CertificateStatus,
      sentDate: row[6] || '',
    }))
    .filter((cert) => cert.name && cert.email && cert.certificateId);
}

export async function getPendingCertificates(): Promise<Certificate[]> {
  const all = await getAllCertificates();
  return all.filter((c) => c.status === 'Pending');
}

export async function getCertificateById(certificateId: string): Promise<Certificate | null> {
  const all = await getAllCertificates();
  return all.find((c) => c.certificateId === certificateId) || null;
}

export async function updateCertificateStatus(
  rowIndex: number,
  status: CertificateStatus,
  sentDate?: string
): Promise<void> {
  const sheets = getSheets();
  const statusRange = `Sheet1!F${rowIndex}`;
  const dateRange = `Sheet1!G${rowIndex}`;

  await sheets.spreadsheets.values.update({
    spreadsheetId: SHEET_ID,
    range: statusRange,
    valueInputOption: 'RAW',
    requestBody: { values: [[status]] },
  });

  if (sentDate) {
    await sheets.spreadsheets.values.update({
      spreadsheetId: SHEET_ID,
      range: dateRange,
      valueInputOption: 'RAW',
      requestBody: { values: [[sentDate]] },
    });
  }
}

export async function getDashboardStats() {
  const all = await getAllCertificates();
  return {
    total: all.length,
    pending: all.filter((c) => c.status === 'Pending').length,
    generated: all.filter((c) => c.status === 'Generated').length,
    sent: all.filter((c) => c.status === 'Sent').length,
    failed: all.filter((c) => c.status === 'Failed').length,
  };
}
