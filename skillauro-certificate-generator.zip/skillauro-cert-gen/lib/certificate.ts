import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import QRCode from 'qrcode';
import path from 'path';
import fs from 'fs';
import { Certificate } from '@/types';

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://yourdomain.com';

export async function generateCertificatePDF(cert: Certificate): Promise<Buffer> {
  const templatePath = path.join(process.cwd(), 'public', 'certificate-template.png');

  // Load template image if it exists, else create a placeholder certificate
  let templateImageBytes: Buffer | null = null;
  if (fs.existsSync(templatePath)) {
    templateImageBytes = fs.readFileSync(templatePath);
  }

  const pdfDoc = await PDFDocument.create();

  // A4 landscape dimensions in points (1pt = 1/72 inch)
  const pageWidth = 841.89;
  const pageHeight = 595.28;
  const page = pdfDoc.addPage([pageWidth, pageHeight]);

  // Embed template image or create a styled background
  if (templateImageBytes) {
    const templateImage = await pdfDoc.embedPng(templateImageBytes);
    page.drawImage(templateImage, {
      x: 0,
      y: 0,
      width: pageWidth,
      height: pageHeight,
    });
  } else {
    // Fallback: Draw a professional certificate background
    await drawFallbackBackground(pdfDoc, page, pageWidth, pageHeight);
  }

  // Load fonts
  const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const regularFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const italicFont = await pdfDoc.embedFont(StandardFonts.HelveticaOblique);

  if (!templateImageBytes) {
    // Draw text only on fallback (template handles its own layout)
    // Organization header
    page.drawText('SKILLAURO TECHNOLOGIES', {
      x: pageWidth / 2 - boldFont.widthOfTextAtSize('SKILLAURO TECHNOLOGIES', 28) / 2,
      y: pageHeight - 100,
      size: 28,
      font: boldFont,
      color: rgb(0.192, 0.180, 0.639), // brand-700 #3730a3
    });

    page.drawText('CERTIFICATE OF INTERNSHIP', {
      x: pageWidth / 2 - boldFont.widthOfTextAtSize('CERTIFICATE OF INTERNSHIP', 18) / 2,
      y: pageHeight - 135,
      size: 18,
      font: boldFont,
      color: rgb(0.31, 0.27, 0.64),
    });

    // Divider line
    page.drawLine({
      start: { x: 80, y: pageHeight - 150 },
      end: { x: pageWidth - 80, y: pageHeight - 150 },
      thickness: 1,
      color: rgb(0.78, 0.78, 0.85),
    });

    // "This is to certify that"
    page.drawText('This is to certify that', {
      x: pageWidth / 2 - regularFont.widthOfTextAtSize('This is to certify that', 14) / 2,
      y: pageHeight - 200,
      size: 14,
      font: italicFont,
      color: rgb(0.4, 0.4, 0.45),
    });

    // Recipient name
    const nameSize = 36;
    page.drawText(cert.name, {
      x: pageWidth / 2 - boldFont.widthOfTextAtSize(cert.name, nameSize) / 2,
      y: pageHeight - 255,
      size: nameSize,
      font: boldFont,
      color: rgb(0.12, 0.11, 0.35),
    });

    // "has successfully completed"
    const completedText = `has successfully completed the internship program in`;
    page.drawText(completedText, {
      x: pageWidth / 2 - regularFont.widthOfTextAtSize(completedText, 13) / 2,
      y: pageHeight - 295,
      size: 13,
      font: regularFont,
      color: rgb(0.4, 0.4, 0.45),
    });

    // Domain
    const domainSize = 22;
    page.drawText(cert.domain, {
      x: pageWidth / 2 - boldFont.widthOfTextAtSize(cert.domain, domainSize) / 2,
      y: pageHeight - 335,
      size: domainSize,
      font: boldFont,
      color: rgb(0.192, 0.180, 0.639),
    });

    // Issue date
    page.drawText(`Issue Date: ${cert.issueDate}`, {
      x: 100,
      y: pageHeight - 400,
      size: 11,
      font: regularFont,
      color: rgb(0.45, 0.45, 0.50),
    });

    // Certificate ID
    page.drawText(`Certificate ID: ${cert.certificateId}`, {
      x: 100,
      y: pageHeight - 420,
      size: 11,
      font: boldFont,
      color: rgb(0.3, 0.3, 0.35),
    });

    // Signature area
    page.drawLine({
      start: { x: pageWidth - 260, y: pageHeight - 430 },
      end: { x: pageWidth - 100, y: pageHeight - 430 },
      thickness: 1,
      color: rgb(0.3, 0.3, 0.35),
    });
    page.drawText('Authorized Signatory', {
      x: pageWidth - 250,
      y: pageHeight - 448,
      size: 10,
      font: regularFont,
      color: rgb(0.45, 0.45, 0.50),
    });
    page.drawText('Skillauro Technologies', {
      x: pageWidth - 245,
      y: pageHeight - 462,
      size: 10,
      font: boldFont,
      color: rgb(0.3, 0.3, 0.35),
    });
  } else {
    // Draw text placeholders over template image
    // These positions should match the template layout
    // NAME
    const nameSize = 32;
    page.drawText(cert.name, {
      x: pageWidth / 2 - boldFont.widthOfTextAtSize(cert.name, nameSize) / 2,
      y: pageHeight - 260,
      size: nameSize,
      font: boldFont,
      color: rgb(0.12, 0.11, 0.35),
    });

    // Domain
    page.drawText(cert.domain, {
      x: pageWidth / 2 - boldFont.widthOfTextAtSize(cert.domain, 20) / 2,
      y: pageHeight - 320,
      size: 20,
      font: boldFont,
      color: rgb(0.192, 0.180, 0.639),
    });

    // Certificate ID
    page.drawText(cert.certificateId, {
      x: 120,
      y: 100,
      size: 11,
      font: boldFont,
      color: rgb(0.3, 0.3, 0.35),
    });

    // Issue Date
    page.drawText(cert.issueDate, {
      x: 120,
      y: 80,
      size: 11,
      font: regularFont,
      color: rgb(0.45, 0.45, 0.50),
    });
  }

  // Generate QR code
  const verifyUrl = `${APP_URL}/verify?cid=${cert.certificateId}`;
  const qrDataUrl = await QRCode.toDataURL(verifyUrl, {
    width: 100,
    margin: 1,
    color: { dark: '#000000', light: '#ffffff' },
  });

  // Convert data URL to bytes
  const qrBase64 = qrDataUrl.replace(/^data:image\/png;base64,/, '');
  const qrBytes = Buffer.from(qrBase64, 'base64');
  const qrImage = await pdfDoc.embedPng(qrBytes);

  // Place QR code at bottom-right
  const qrSize = 80;
  page.drawImage(qrImage, {
    x: pageWidth - qrSize - 30,
    y: 30,
    width: qrSize,
    height: qrSize,
  });

  // Small "Verify" label under QR
  page.drawText('Scan to Verify', {
    x: pageWidth - qrSize - 22,
    y: 20,
    size: 7,
    font: regularFont,
    color: rgb(0.5, 0.5, 0.55),
  });

  const pdfBytes = await pdfDoc.save();
  return Buffer.from(pdfBytes);
}

async function drawFallbackBackground(
  pdfDoc: PDFDocument,
  page: ReturnType<PDFDocument['addPage']>,
  width: number,
  height: number
) {
  // Outer border double line
  page.drawRectangle({
    x: 20,
    y: 20,
    width: width - 40,
    height: height - 40,
    borderColor: rgb(0.192, 0.180, 0.639),
    borderWidth: 2,
    color: rgb(0.98, 0.98, 1.0),
  });
  page.drawRectangle({
    x: 30,
    y: 30,
    width: width - 60,
    height: height - 60,
    borderColor: rgb(0.63, 0.62, 0.85),
    borderWidth: 0.5,
    color: undefined,
  });

  // Top decorative band
  page.drawRectangle({
    x: 20,
    y: height - 75,
    width: width - 40,
    height: 55,
    color: rgb(0.192, 0.180, 0.639),
    borderWidth: 0,
  });

  // Bottom band
  page.drawRectangle({
    x: 20,
    y: 20,
    width: width - 40,
    height: 30,
    color: rgb(0.192, 0.180, 0.639),
    borderWidth: 0,
  });
}

export async function generateCertificatePreviewBase64(cert: Certificate): Promise<string> {
  const pdfBytes = await generateCertificatePDF(cert);
  return pdfBytes.toString('base64');
}
