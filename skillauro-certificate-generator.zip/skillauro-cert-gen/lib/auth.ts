import { SignJWT, jwtVerify } from 'jose';

const SECRET = new TextEncoder().encode(
  process.env.AUTH_SECRET || 'skillauro-secret-key-change-in-production'
);

export async function signToken(payload: Record<string, string>): Promise<string> {
  return await new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('24h')
    .sign(SECRET);
}

export async function verifyToken(token: string): Promise<Record<string, string> | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET);
    return payload as Record<string, string>;
  } catch {
    return null;
  }
}

export function getAuthCookieName() {
  return 'skillauro_auth';
}
