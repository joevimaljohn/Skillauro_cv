import { Resend } from 'resend';
import { Certificate } from '@/types';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function sendCertificateEmail(
  cert: Certificate,
  pdfBuffer: Buffer
): Promise<void> {
  const emailBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 40px auto; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.08); }
    .header { background: #3730a3; padding: 36px 40px; text-align: center; }
    .header h1 { color: #fff; margin: 0; font-size: 22px; letter-spacing: 1px; }
    .header p { color: #c7d2fe; margin: 6px 0 0; font-size: 13px; }
    .body { padding: 36px 40px; }
    .body p { color: #374151; font-size: 15px; line-height: 1.7; margin: 0 0 16px; }
    .cert-box { background: #eef2ff; border-left: 4px solid #6366f1; border-radius: 6px; padding: 20px 24px; margin: 24px 0; }
    .cert-box p { margin: 4px 0; font-size: 14px; }
    .cert-box strong { color: #3730a3; }
    .footer { background: #f9fafb; padding: 24px 40px; text-align: center; }
    .footer p { color: #9ca3af; font-size: 12px; margin: 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Skillauro Technologies</h1>
      <p>Internship Certificate</p>
    </div>
    <div class="body">
      <p>Dear <strong>${cert.name}</strong>,</p>
      <p>Congratulations on successfully completing your internship program at <strong>Skillauro Technologies</strong>. We are proud of your dedication and hard work throughout the program.</p>
      <p>Please find your official certificate attached to this email.</p>
      <div class="cert-box">
        <p><strong>Certificate ID:</strong> ${cert.certificateId}</p>
        <p><strong>Domain:</strong> ${cert.domain}</p>
        <p><strong>Issue Date:</strong> ${cert.issueDate}</p>
        <p><strong>Recipient:</strong> ${cert.name}</p>
      </div>
      <p>You can verify your certificate anytime at:<br />
        <a href="${process.env.NEXT_PUBLIC_APP_URL}/verify?cid=${cert.certificateId}" style="color:#4f46e5;">
          ${process.env.NEXT_PUBLIC_APP_URL}/verify?cid=${cert.certificateId}
        </a>
      </p>
      <p>We wish you the best in your future endeavors!</p>
      <p>Warm regards,<br /><strong>Skillauro Technologies</strong></p>
    </div>
    <div class="footer">
      <p>© ${new Date().getFullYear()} Skillauro Technologies · MSME Approved · ISO Certified</p>
    </div>
  </div>
</body>
</html>
  `.trim();

  await resend.emails.send({
    from: 'Skillauro Technologies <certificates@skillauro.in>',
    to: cert.email,
    subject: `Internship Certificate – Skillauro Technologies`,
    html: emailBody,
    attachments: [
      {
        filename: `${cert.certificateId}.pdf`,
        content: pdfBuffer,
      },
    ],
  });
}
