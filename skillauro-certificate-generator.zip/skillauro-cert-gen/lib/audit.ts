import { AuditLog } from '@/types';

// In production, replace with a database (e.g. Vercel KV, PlanetScale, Supabase)
// For now, we store logs in a module-level array (persists per serverless instance)
const auditLogs: AuditLog[] = [];

export function addAuditLog(
  action: string,
  details: string,
  success: boolean,
  certificateId?: string
): AuditLog {
  const log: AuditLog = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    action,
    details,
    success,
    certificateId,
    timestamp: new Date().toISOString(),
  };
  auditLogs.unshift(log);
  // Keep only last 500 logs
  if (auditLogs.length > 500) auditLogs.pop();
  return log;
}

export function getAuditLogs(limit = 50): AuditLog[] {
  return auditLogs.slice(0, limit);
}
