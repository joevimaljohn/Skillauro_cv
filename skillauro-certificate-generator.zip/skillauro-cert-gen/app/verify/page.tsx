'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { CheckCircle2, XCircle, Loader2, ShieldCheck, Calendar, User, Award } from 'lucide-react';
import { formatDate } from '@/lib/utils';

interface VerifyResult {
  name: string;
  certificateId: string;
  domain: string;
  issueDate: string;
  status: string;
}

function VerifyContent() {
  const searchParams = useSearchParams();
  const cid = searchParams.get('cid') || '';
  const [result, setResult] = useState<VerifyResult | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [inputCid, setInputCid] = useState(cid);

  useEffect(() => {
    if (cid) verify(cid);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cid]);

  async function verify(id: string) {
    if (!id.trim()) return;
    setLoading(true);
    setResult(null);
    setError('');
    setSearched(true);
    try {
      const res = await fetch(`/api/verify?cid=${encodeURIComponent(id.trim())}`);
      const data = await res.json();
      if (data.success) {
        setResult(data.data);
      } else {
        setError('Certificate not found. Please check the ID and try again.');
      }
    } catch {
      setError('Verification service unavailable. Please try again later.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[var(--bg)] flex flex-col items-center justify-center px-4 py-12">
      {/* Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-brand-500/8 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-emerald-500/8 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-lg">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-brand-600 shadow-lg mb-4">
            <ShieldCheck className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-[var(--text)]">Certificate Verification</h1>
          <p className="text-sm text-[var(--text-muted)] mt-1">Skillauro Technologies</p>
        </div>

        {/* Search card */}
        <div className="card mb-6">
          <label className="block text-sm font-medium mb-2">Certificate ID</label>
          <div className="flex gap-2">
            <input
              type="text"
              className="input font-mono flex-1"
              placeholder="e.g. SKL-INT-CS011"
              value={inputCid}
              onChange={(e) => setInputCid(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && verify(inputCid)}
            />
            <button
              onClick={() => verify(inputCid)}
              disabled={loading || !inputCid.trim()}
              className="btn-primary px-5"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Verify'}
            </button>
          </div>
        </div>

        {/* Loading */}
        {loading && (
          <div className="card text-center py-10">
            <Loader2 className="w-8 h-8 animate-spin text-brand-500 mx-auto mb-3" />
            <p className="text-sm text-[var(--text-muted)]">Verifying certificate…</p>
          </div>
        )}

        {/* Success */}
        {!loading && result && (
          <div className="card border-emerald-200 dark:border-emerald-800">
            <div className="flex items-start gap-4 mb-6">
              <div className="p-2.5 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <h2 className="font-bold text-emerald-700 dark:text-emerald-400 text-lg">
                  Certificate Verified Successfully
                </h2>
                <p className="text-sm text-[var(--text-muted)] mt-0.5">
                  This certificate is authentic and issued by Skillauro Technologies
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <InfoRow icon={User} label="Recipient" value={result.name} />
              <InfoRow icon={ShieldCheck} label="Certificate ID" value={result.certificateId} mono />
              <InfoRow icon={Award} label="Domain" value={result.domain} />
              <InfoRow icon={Calendar} label="Issue Date" value={formatDate(result.issueDate)} />
            </div>

            <div className="mt-6 pt-4 border-t border-[var(--border)]">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                <p className="text-xs text-[var(--text-muted)]">
                  Verified on {new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                  {' · '}Skillauro Technologies · MSME Approved · ISO Certified
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Error */}
        {!loading && searched && error && (
          <div className="card border-red-200 dark:border-red-800">
            <div className="flex items-start gap-4">
              <div className="p-2.5 bg-red-100 dark:bg-red-900/30 rounded-xl">
                <XCircle className="w-6 h-6 text-red-500" />
              </div>
              <div>
                <h2 className="font-bold text-red-600 dark:text-red-400">Certificate Not Found</h2>
                <p className="text-sm text-[var(--text-muted)] mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        <p className="text-center text-xs text-[var(--text-muted)] mt-8">
          © {new Date().getFullYear()} Skillauro Technologies · Powered by Skillauro Certificate System
        </p>
      </div>
    </div>
  );
}

function InfoRow({
  icon: Icon, label, value, mono,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-8 h-8 rounded-lg bg-gray-100 dark:bg-white/5 flex items-center justify-center flex-shrink-0">
        <Icon className="w-4 h-4 text-[var(--text-muted)]" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-[var(--text-muted)]">{label}</p>
        <p className={`font-medium mt-0.5 ${mono ? 'font-mono text-sm' : ''}`}>{value}</p>
      </div>
    </div>
  );
}

export default function VerifyPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
      </div>
    }>
      <VerifyContent />
    </Suspense>
  );
}
