import { NextResponse } from 'next/server';
import { getAuditLogs } from '@/lib/audit';

export async function GET() {
  const logs = getAuditLogs(100);
  return NextResponse.json({ success: true, data: logs });
}
