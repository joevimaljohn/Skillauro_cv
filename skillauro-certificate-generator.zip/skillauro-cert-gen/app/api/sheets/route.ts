import { NextResponse } from 'next/server';
import { getAllCertificates, getDashboardStats } from '@/lib/sheets';
import { addAuditLog } from '@/lib/audit';

export async function GET() {
  try {
    const [certificates, stats] = await Promise.all([
      getAllCertificates(),
      getDashboardStats(),
    ]);
    addAuditLog('SYNC', `Synced ${certificates.length} certificates from Google Sheets`, true);
    return NextResponse.json({ success: true, data: { certificates, stats } });
  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Unknown error';
    addAuditLog('SYNC', `Sync failed: ${msg}`, false);
    return NextResponse.json({ success: false, error: msg }, { status: 500 });
  }
}
