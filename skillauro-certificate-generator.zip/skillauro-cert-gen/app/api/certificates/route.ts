import { NextRequest, NextResponse } from 'next/server';
import { getPendingCertificates, getCertificateById, updateCertificateStatus } from '@/lib/sheets';
import { generateCertificatePDF } from '@/lib/certificate';
import { addAuditLog } from '@/lib/audit';

// GET /api/certificates?id=SKL-INT-CS011 → preview PDF bytes (base64)
export async function GET(req: NextRequest) {
  const cid = req.nextUrl.searchParams.get('id');
  if (!cid) {
    return NextResponse.json({ success: false, error: 'id param required' }, { status: 400 });
  }
  const cert = await getCertificateById(cid);
  if (!cert) {
    return NextResponse.json({ success: false, error: 'Certificate not found' }, { status: 404 });
  }
  const pdfBuffer = await generateCertificatePDF(cert);
  return new NextResponse(new Uint8Array(pdfBuffer), {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `inline; filename="${cert.certificateId}.pdf"`,
    },
  });
}

// POST /api/certificates { action: 'generate-all' | 'generate-one', certificateId?: string }
export async function POST(req: NextRequest) {
  const body = await req.json() as { action: string; certificateId?: string };

  if (body.action === 'generate-one' && body.certificateId) {
    const cert = await getCertificateById(body.certificateId);
    if (!cert) {
      return NextResponse.json({ success: false, error: 'Certificate not found' }, { status: 404 });
    }
    const pdfBuffer = await generateCertificatePDF(cert);
    await updateCertificateStatus(cert.rowIndex, 'Generated');
    addAuditLog('GENERATE', `Generated certificate ${cert.certificateId}`, true, cert.certificateId);
    return new NextResponse(new Uint8Array(pdfBuffer), {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${cert.certificateId}.pdf"`,
      },
    });
  }

  if (body.action === 'generate-all') {
    const pending = await getPendingCertificates();
    const results = { total: pending.length, success: 0, failed: 0, errors: [] as { certificateId: string; error: string }[] };

    for (const cert of pending) {
      try {
        await generateCertificatePDF(cert);
        await updateCertificateStatus(cert.rowIndex, 'Generated');
        results.success++;
        addAuditLog('GENERATE', `Generated ${cert.certificateId}`, true, cert.certificateId);
      } catch (e) {
        results.failed++;
        const msg = e instanceof Error ? e.message : 'Unknown';
        results.errors.push({ certificateId: cert.certificateId, error: msg });
        await updateCertificateStatus(cert.rowIndex, 'Failed');
        addAuditLog('GENERATE', `Failed to generate ${cert.certificateId}: ${msg}`, false, cert.certificateId);
      }
    }
    return NextResponse.json({ success: true, data: results });
  }

  return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
}
