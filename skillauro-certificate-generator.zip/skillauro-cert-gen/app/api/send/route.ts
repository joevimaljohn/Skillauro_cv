import { NextRequest, NextResponse } from 'next/server';
import { getPendingCertificates, getCertificateById, getAllCertificates, updateCertificateStatus } from '@/lib/sheets';
import { generateCertificatePDF } from '@/lib/certificate';
import { sendCertificateEmail } from '@/lib/email';
import { addAuditLog } from '@/lib/audit';
import { getTodayString } from '@/lib/utils';

// POST /api/send
// body: { action: 'send-one' | 'send-pending' | 'generate-and-send', certificateId?: string }
export async function POST(req: NextRequest) {
  const body = await req.json() as { action: string; certificateId?: string };
  const today = getTodayString();

  // Send a single certificate
  if (body.action === 'send-one' && body.certificateId) {
    const cert = await getCertificateById(body.certificateId);
    if (!cert) {
      return NextResponse.json({ success: false, error: 'Certificate not found' }, { status: 404 });
    }
    try {
      const pdf = await generateCertificatePDF(cert);
      await sendCertificateEmail(cert, pdf);
      await updateCertificateStatus(cert.rowIndex, 'Sent', today);
      addAuditLog('SEND', `Sent certificate ${cert.certificateId} to ${cert.email}`, true, cert.certificateId);
      return NextResponse.json({ success: true, message: 'Certificate sent successfully' });
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown';
      addAuditLog('SEND', `Failed to send ${cert.certificateId}: ${msg}`, false, cert.certificateId);
      return NextResponse.json({ success: false, error: msg }, { status: 500 });
    }
  }

  // Send all pending
  if (body.action === 'send-pending' || body.action === 'generate-and-send') {
    let certs;
    if (body.action === 'generate-and-send') {
      certs = await getAllCertificates();
      certs = certs.filter((c) => c.status !== 'Sent');
    } else {
      certs = await getPendingCertificates();
    }

    const results = {
      total: certs.length,
      success: 0,
      failed: 0,
      errors: [] as { certificateId: string; error: string }[],
    };

    for (const cert of certs) {
      try {
        const pdf = await generateCertificatePDF(cert);
        await sendCertificateEmail(cert, pdf);
        await updateCertificateStatus(cert.rowIndex, 'Sent', today);
        results.success++;
        addAuditLog('SEND', `Sent ${cert.certificateId} to ${cert.email}`, true, cert.certificateId);
      } catch (e) {
        results.failed++;
        const msg = e instanceof Error ? e.message : 'Unknown';
        results.errors.push({ certificateId: cert.certificateId, error: msg });
        await updateCertificateStatus(cert.rowIndex, 'Failed');
        addAuditLog('SEND', `Failed to send ${cert.certificateId}: ${msg}`, false, cert.certificateId);
      }
    }

    return NextResponse.json({ success: true, data: results });
  }

  return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
}
