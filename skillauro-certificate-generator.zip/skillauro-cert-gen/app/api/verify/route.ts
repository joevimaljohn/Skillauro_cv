import { NextRequest, NextResponse } from 'next/server';
import { getCertificateById } from '@/lib/sheets';

export async function GET(req: NextRequest) {
  const cid = req.nextUrl.searchParams.get('cid');
  if (!cid) {
    return NextResponse.json({ success: false, error: 'Certificate ID required' }, { status: 400 });
  }

  try {
    const cert = await getCertificateById(cid);
    if (!cert) {
      return NextResponse.json({ success: false, error: 'Certificate not found' }, { status: 404 });
    }
    return NextResponse.json({
      success: true,
      data: {
        name: cert.name,
        certificateId: cert.certificateId,
        domain: cert.domain,
        issueDate: cert.issueDate,
        status: cert.status,
      },
    });
  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ success: false, error: msg }, { status: 500 });
  }
}
