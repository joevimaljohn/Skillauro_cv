'use client';

import { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import {
  FileText, Clock, CheckCircle2, Send, RefreshCw, Zap,
  Mail, AlertCircle, Loader2, Activity,
} from 'lucide-react';
import { StatCard } from '@/components/dashboard/StatCard';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { formatDate } from '@/lib/utils';
import type { Certificate, DashboardStats, BulkResult } from '@/types';

type LoadingAction = 'sync' | 'generate' | 'send' | 'all' | null;

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recent, setRecent] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState<LoadingAction>(null);
  const [bulkResult, setBulkResult] = useState<BulkResult | null>(null);

  const sync = useCallback(async (silent = false) => {
    if (!silent) setLoading('sync');
    try {
      const res = await fetch('/api/sheets');
      const data = await res.json();
      if (data.success) {
        setStats(data.data.stats);
        setRecent(data.data.certificates.slice(-10).reverse());
        if (!silent) toast.success('Synced from Google Sheets');
      } else {
        toast.error(data.error || 'Sync failed');
      }
    } catch {
      toast.error('Failed to connect to Google Sheets');
    } finally {
      setLoading(null);
    }
  }, []);

  useEffect(() => { sync(true); }, [sync]);

  async function bulkAction(action: string, label: string, loadKey: LoadingAction) {
    setLoading(loadKey);
    setBulkResult(null);
    const endpoint = action.includes('send') ? '/api/send' : '/api/certificates';
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (data.success) {
        setBulkResult(data.data);
        toast.success(`${label} complete: ${data.data.success}/${data.data.total} succeeded`);
        await sync(true);
      } else {
        toast.error(data.error || `${label} failed`);
      }
    } catch {
      toast.error('Request failed');
    } finally {
      setLoading(null);
    }
  }

  const actions = [
    {
      label: 'Sync Sheet',
      icon: RefreshCw,
      key: 'sync' as LoadingAction,
      onClick: () => sync(),
      variant: 'btn-secondary',
    },
    {
      label: 'Generate Pending',
      icon: Zap,
      key: 'generate' as LoadingAction,
      onClick: () => bulkAction('generate-all', 'Generate', 'generate'),
      variant: 'btn-secondary',
    },
    {
      label: 'Send Pending',
      icon: Mail,
      key: 'send' as LoadingAction,
      onClick: () => bulkAction('send-pending', 'Send', 'send'),
      variant: 'btn-secondary',
    },
    {
      label: 'Generate & Send All',
      icon: Send,
      key: 'all' as LoadingAction,
      onClick: () => bulkAction('generate-and-send', 'Generate & Send', 'all'),
      variant: 'btn-primary',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text)]">Dashboard</h1>
          <p className="text-sm text-[var(--text-muted)] mt-0.5">
            Manage and dispatch Skillauro internship certificates
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {actions.map(({ label, icon: Icon, key, onClick, variant }) => (
            <button
              key={key}
              onClick={onClick}
              disabled={loading !== null}
              className={variant}
            >
              {loading === key ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Icon className="w-4 h-4" />
              )}
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      {stats ? (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <StatCard label="Total" value={stats.total} icon={FileText} color="purple" />
          <StatCard label="Pending" value={stats.pending} icon={Clock} color="amber" />
          <StatCard label="Generated" value={stats.generated} icon={CheckCircle2} color="blue" />
          <StatCard label="Sent" value={stats.sent} icon={Send} color="emerald" />
          <StatCard label="Failed" value={stats.failed} icon={AlertCircle} color="red" />
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="card animate-pulse">
              <div className="h-4 w-20 bg-gray-200 dark:bg-gray-700 rounded mb-3" />
              <div className="h-8 w-12 bg-gray-200 dark:bg-gray-700 rounded" />
            </div>
          ))}
        </div>
      )}

      {/* Bulk result */}
      {bulkResult && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4 text-brand-500" />
            <h3 className="font-semibold">Operation Result</h3>
          </div>
          <ProgressBar
            total={bulkResult.total}
            success={bulkResult.success}
            failed={bulkResult.failed}
          />
          {bulkResult.errors.length > 0 && (
            <div className="mt-4 space-y-1">
              <p className="text-sm font-medium text-red-500">Failures:</p>
              {bulkResult.errors.map((e, i) => (
                <div key={i} className="text-xs text-[var(--text-muted)] bg-red-50 dark:bg-red-900/10 rounded px-3 py-1.5">
                  <span className="font-mono text-red-600">{e.certificateId}</span> — {e.error}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Recent activity */}
      <div className="card">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-semibold flex items-center gap-2">
            <Activity className="w-4 h-4 text-[var(--text-muted)]" />
            Recent Certificates
          </h3>
          <a href="/dashboard/certificates" className="text-xs text-brand-500 hover:text-brand-600 font-medium">
            View all →
          </a>
        </div>

        {recent.length === 0 ? (
          <div className="text-center py-12 text-[var(--text-muted)]">
            <FileText className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No certificates yet. Sync your Google Sheet to get started.</p>
          </div>
        ) : (
          <div className="overflow-x-auto -mx-2">
            <table className="w-full text-sm min-w-[600px]">
              <thead>
                <tr className="text-left text-xs text-[var(--text-muted)] border-b border-[var(--border)]">
                  <th className="pb-3 px-2 font-medium">Name</th>
                  <th className="pb-3 px-2 font-medium">Certificate ID</th>
                  <th className="pb-3 px-2 font-medium">Domain</th>
                  <th className="pb-3 px-2 font-medium">Issue Date</th>
                  <th className="pb-3 px-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border)]">
                {recent.map((cert) => (
                  <tr key={cert.certificateId} className="table-row-hover">
                    <td className="py-3 px-2 font-medium">{cert.name}</td>
                    <td className="py-3 px-2 font-mono text-xs text-[var(--text-muted)]">
                      {cert.certificateId}
                    </td>
                    <td className="py-3 px-2 text-[var(--text-muted)]">{cert.domain}</td>
                    <td className="py-3 px-2 text-[var(--text-muted)]">{formatDate(cert.issueDate)}</td>
                    <td className="py-3 px-2">
                      <StatusBadge status={cert.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
