'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import toast from 'react-hot-toast';
import { Search, Download, Send, Loader2, FileText, ZoomIn, ZoomOut } from 'lucide-react';
import { StatusBadge } from '@/components/ui/StatusBadge';
import type { Certificate } from '@/types';

function PreviewContent() {
  const searchParams = useSearchParams();
  const initialId = searchParams.get('id') || '';
  const [certId, setCertId] = useState(initialId);
  const [inputId, setInputId] = useState(initialId);
  const [cert, setCert] = useState<Certificate | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    if (certId) loadPreview(certId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [certId]);

  async function loadPreview(id: string) {
    setLoading(true);
    setPdfUrl(null);
    setCert(null);
    try {
      // Load certificate metadata
      const sheetRes = await fetch('/api/sheets');
      const sheetData = await sheetRes.json();
      if (sheetData.success) {
        const found = sheetData.data.certificates.find(
          (c: Certificate) => c.certificateId === id
        );
        if (found) {
          setCert(found);
        } else {
          toast.error('Certificate not found in sheet');
          setLoading(false);
          return;
        }
      }

      // Load PDF preview
      const pdfRes = await fetch(`/api/certificates?id=${id}`);
      if (pdfRes.ok) {
        const blob = await pdfRes.blob();
        const url = URL.createObjectURL(blob);
        setPdfUrl(url);
      } else {
        toast.error('Failed to generate preview');
      }
    } catch {
      toast.error('Preview error');
    } finally {
      setLoading(false);
    }
  }

  async function sendEmail() {
    if (!cert) return;
    setSending(true);
    try {
      const res = await fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'send-one', certificateId: cert.certificateId }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(`Certificate sent to ${cert.email}`);
      } else {
        toast.error(data.error || 'Send failed');
      }
    } catch {
      toast.error('Send error');
    } finally {
      setSending(false);
    }
  }

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (inputId.trim()) setCertId(inputId.trim());
  }

  function downloadPdf() {
    if (!pdfUrl || !cert) return;
    const a = document.createElement('a');
    a.href = pdfUrl;
    a.download = `${cert.certificateId}.pdf`;
    a.click();
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Certificate Preview</h1>
        <p className="text-sm text-[var(--text-muted)] mt-0.5">
          Preview generated certificate before sending
        </p>
      </div>

      {/* Search */}
      <div className="card">
        <form onSubmit={handleSearch} className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
            <input
              type="text"
              placeholder="Enter Certificate ID (e.g. SKL-INT-CS011)"
              className="input pl-9 font-mono"
              value={inputId}
              onChange={(e) => setInputId(e.target.value)}
            />
          </div>
          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            Preview
          </button>
        </form>
      </div>

      {/* Cert info */}
      {cert && (
        <div className="card">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 flex-1">
              <div>
                <p className="text-xs text-[var(--text-muted)]">Name</p>
                <p className="font-medium mt-0.5">{cert.name}</p>
              </div>
              <div>
                <p className="text-xs text-[var(--text-muted)]">Certificate ID</p>
                <p className="font-mono text-sm mt-0.5">{cert.certificateId}</p>
              </div>
              <div>
                <p className="text-xs text-[var(--text-muted)]">Domain</p>
                <p className="mt-0.5">{cert.domain}</p>
              </div>
              <div>
                <p className="text-xs text-[var(--text-muted)]">Status</p>
                <div className="mt-0.5"><StatusBadge status={cert.status} /></div>
              </div>
            </div>
            <div className="flex gap-2">
              {pdfUrl && (
                <button onClick={downloadPdf} className="btn-secondary">
                  <Download className="w-4 h-4" />
                  Download
                </button>
              )}
              <button
                onClick={sendEmail}
                disabled={sending || cert.status === 'Sent'}
                className="btn-primary"
              >
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                {cert.status === 'Sent' ? 'Already Sent' : 'Send Email'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PDF viewer */}
      {loading && (
        <div className="card flex items-center justify-center h-80">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin text-brand-500 mx-auto mb-3" />
            <p className="text-sm text-[var(--text-muted)]">Generating preview…</p>
          </div>
        </div>
      )}

      {pdfUrl && !loading && (
        <div className="card p-0 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--border)]">
            <span className="text-sm font-medium">PDF Preview</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setScale((s) => Math.max(0.5, s - 0.1))}
                className="btn-ghost p-1.5"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-xs text-[var(--text-muted)] w-10 text-center">
                {Math.round(scale * 100)}%
              </span>
              <button
                onClick={() => setScale((s) => Math.min(2, s + 0.1))}
                className="btn-ghost p-1.5"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className="bg-gray-100 dark:bg-gray-900 overflow-auto p-4" style={{ maxHeight: '600px' }}>
            <div style={{ transform: `scale(${scale})`, transformOrigin: 'top center', transition: 'transform 0.2s' }}>
              <iframe
                src={pdfUrl}
                className="w-full rounded shadow-lg bg-white"
                style={{ height: '500px', minWidth: '700px' }}
                title="Certificate Preview"
              />
            </div>
          </div>
        </div>
      )}

      {!loading && !pdfUrl && !cert && (
        <div className="card flex items-center justify-center h-64">
          <div className="text-center text-[var(--text-muted)]">
            <FileText className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p className="text-sm">Enter a Certificate ID above to preview</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default function PreviewPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-brand-500" /></div>}>
      <PreviewContent />
    </Suspense>
  );
}
