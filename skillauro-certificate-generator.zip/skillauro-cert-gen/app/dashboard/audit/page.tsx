'use client';

import { useState, useEffect } from 'react';
import { RefreshCw, CheckCircle2, XCircle, ClipboardList } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { AuditLog } from '@/types';

export default function AuditPage() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);

  async function fetchLogs() {
    setLoading(true);
    try {
      const res = await fetch('/api/audit');
      const data = await res.json();
      if (data.success) setLogs(data.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { fetchLogs(); }, []);

  function formatTime(ts: string) {
    return new Date(ts).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    });
  }

  const ACTION_COLORS: Record<string, string> = {
    SYNC: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
    GENERATE: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
    SEND: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Audit Logs</h1>
          <p className="text-sm text-[var(--text-muted)] mt-0.5">
            Activity history for certificate operations
          </p>
        </div>
        <button onClick={fetchLogs} className="btn-secondary" disabled={loading}>
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[600px]">
            <thead className="bg-gray-50 dark:bg-white/5">
              <tr className="text-left text-xs text-[var(--text-muted)]">
                <th className="px-4 py-3.5 font-medium">Time</th>
                <th className="px-4 py-3.5 font-medium">Action</th>
                <th className="px-4 py-3.5 font-medium">Certificate ID</th>
                <th className="px-4 py-3.5 font-medium">Details</th>
                <th className="px-4 py-3.5 font-medium">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {loading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    {Array.from({ length: 5 }).map((_, j) => (
                      <td key={j} className="px-4 py-3.5">
                        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-16 text-[var(--text-muted)]">
                    <ClipboardList className="w-10 h-10 mx-auto mb-3 opacity-25" />
                    <p>No activity yet</p>
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="table-row-hover">
                    <td className="px-4 py-3.5 text-xs text-[var(--text-muted)] whitespace-nowrap">
                      {formatTime(log.timestamp)}
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={cn('badge', ACTION_COLORS[log.action] || 'bg-gray-100 text-gray-700')}>
                        {log.action}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 font-mono text-xs text-[var(--text-muted)]">
                      {log.certificateId || '—'}
                    </td>
                    <td className="px-4 py-3.5 text-[var(--text-muted)] max-w-xs truncate text-xs">
                      {log.details}
                    </td>
                    <td className="px-4 py-3.5">
                      {log.success ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-500" />
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
