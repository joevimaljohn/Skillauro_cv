'use client';

import { useState, useEffect, useMemo } from 'react';
import toast from 'react-hot-toast';
import {
  Search, Filter, Download, Send, Eye, Loader2,
  RefreshCw, FileText, X, ChevronDown,
} from 'lucide-react';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { formatDate } from '@/lib/utils';
import type { Certificate } from '@/types';

const STATUS_OPTIONS = ['All', 'Pending', 'Generated', 'Sent', 'Failed'];

export default function CertificatesPage() {
  const [certs, setCerts] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [domainFilter, setDomainFilter] = useState('All');
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  async function fetchCerts() {
    setLoading(true);
    try {
      const res = await fetch('/api/sheets');
      const data = await res.json();
      if (data.success) setCerts(data.data.certificates);
      else toast.error(data.error || 'Failed to load');
    } catch {
      toast.error('Connection error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { fetchCerts(); }, []);

  const domains = useMemo(
    () => ['All', ...Array.from(new Set(certs.map((c) => c.domain).filter(Boolean)))],
    [certs]
  );

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return certs.filter((c) => {
      const matchSearch =
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.certificateId.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.domain.toLowerCase().includes(q);
      const matchStatus = statusFilter === 'All' || c.status === statusFilter;
      const matchDomain = domainFilter === 'All' || c.domain === domainFilter;
      return matchSearch && matchStatus && matchDomain;
    });
  }, [certs, search, statusFilter, domainFilter]);

  async function sendOne(cert: Certificate) {
    setActionLoading(cert.certificateId);
    try {
      const res = await fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'send-one', certificateId: cert.certificateId }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(`Certificate sent to ${cert.email}`);
        await fetchCerts();
      } else {
        toast.error(data.error || 'Send failed');
      }
    } catch {
      toast.error('Failed to send');
    } finally {
      setActionLoading(null);
    }
  }

  async function downloadOne(cert: Certificate) {
    setActionLoading(`dl-${cert.certificateId}`);
    try {
      const res = await fetch(`/api/certificates?id=${cert.certificateId}`);
      if (!res.ok) { toast.error('Failed to generate PDF'); return; }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${cert.certificateId}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('PDF downloaded');
    } catch {
      toast.error('Download failed');
    } finally {
      setActionLoading(null);
    }
  }

  async function downloadAllZip() {
    setActionLoading('zip');
    try {
      const JSZip = (await import('jszip')).default;
      const zip = new JSZip();
      const toProcess = filtered.filter((c) => c.status !== 'Failed');
      toast.loading(`Generating ${toProcess.length} PDFs…`, { id: 'zip' });
      for (const cert of toProcess) {
        const res = await fetch(`/api/certificates?id=${cert.certificateId}`);
        if (res.ok) {
          const ab = await res.arrayBuffer();
          zip.file(`${cert.certificateId}.pdf`, ab);
        }
      }
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'skillauro-certificates.zip';
      a.click();
      URL.revokeObjectURL(url);
      toast.success('ZIP downloaded!', { id: 'zip' });
    } catch {
      toast.error('ZIP generation failed', { id: 'zip' });
    } finally {
      setActionLoading(null);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Certificates</h1>
          <p className="text-sm text-[var(--text-muted)] mt-0.5">
            {certs.length} total · {filtered.length} shown
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={fetchCerts} className="btn-secondary" disabled={loading}>
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          <button onClick={downloadAllZip} className="btn-secondary" disabled={actionLoading === 'zip'}>
            {actionLoading === 'zip' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            Export ZIP
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
            <input
              type="text"
              placeholder="Search by name, ID, email, or domain…"
              className="input pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-[var(--text)]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
            <select
              className="input pl-9 pr-8 appearance-none cursor-pointer min-w-32"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              {STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}
            </select>
            <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)] pointer-events-none" />
          </div>

          <div className="relative">
            <select
              className="input pr-8 appearance-none cursor-pointer min-w-40"
              value={domainFilter}
              onChange={(e) => setDomainFilter(e.target.value)}
            >
              {domains.map((d) => <option key={d}>{d}</option>)}
            </select>
            <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)] pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[700px]">
            <thead className="bg-gray-50 dark:bg-white/5">
              <tr className="text-left text-xs text-[var(--text-muted)]">
                {['Name', 'Email', 'Domain', 'Certificate ID', 'Issue Date', 'Status', 'Actions'].map((h) => (
                  <th key={h} className="px-4 py-3.5 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    {Array.from({ length: 7 }).map((_, j) => (
                      <td key={j} className="px-4 py-3.5">
                        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-16 text-[var(--text-muted)]">
                    <FileText className="w-10 h-10 mx-auto mb-3 opacity-25" />
                    <p>No certificates found</p>
                  </td>
                </tr>
              ) : (
                filtered.map((cert) => (
                  <tr key={cert.certificateId} className="table-row-hover">
                    <td className="px-4 py-3.5 font-medium">{cert.name}</td>
                    <td className="px-4 py-3.5 text-[var(--text-muted)] text-xs">{cert.email}</td>
                    <td className="px-4 py-3.5 text-[var(--text-muted)]">{cert.domain}</td>
                    <td className="px-4 py-3.5 font-mono text-xs text-[var(--text-muted)]">
                      {cert.certificateId}
                    </td>
                    <td className="px-4 py-3.5 text-[var(--text-muted)]">{formatDate(cert.issueDate)}</td>
                    <td className="px-4 py-3.5">
                      <StatusBadge status={cert.status} />
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1">
                        <a
                          href={`/dashboard/preview?id=${cert.certificateId}`}
                          className="btn-ghost p-1.5"
                          title="Preview"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </a>
                        <button
                          onClick={() => downloadOne(cert)}
                          className="btn-ghost p-1.5"
                          title="Download PDF"
                          disabled={actionLoading === `dl-${cert.certificateId}`}
                        >
                          {actionLoading === `dl-${cert.certificateId}` ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Download className="w-3.5 h-3.5" />
                          )}
                        </button>
                        {cert.status !== 'Sent' && (
                          <button
                            onClick={() => sendOne(cert)}
                            className="btn-ghost p-1.5 text-brand-500 hover:text-brand-600"
                            title="Send email"
                            disabled={actionLoading === cert.certificateId}
                          >
                            {actionLoading === cert.certificateId ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Send className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
